import java.security.SecureClassLoader;

public class VapuClassLoader extends SecureClassLoader {

	public VapuClassLoader(ClassLoader parent) {
		super(parent);
	}
	@Override
	public native Class<?> findClass(String name);
	
	@Override
	protected native void finalize();
}
